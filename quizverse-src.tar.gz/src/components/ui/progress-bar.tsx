import * as React from 'react';
import { cn } from '@/lib/utils/cn';

export interface ProgressBarProps {
  value: number;
  max?: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'gradient' | 'success' | 'error';
  animated?: boolean;
  className?: string;
  timerGradient?: 'safe' | 'medium' | 'low';
}

export function ProgressBar({
  value,
  max = 100,
  showLabel = false,
  size = 'md',
  variant = 'default',
  animated = true,
  className,
  timerGradient,
}: ProgressBarProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);

  const sizes = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-4',
  };

  const timerGradients = {
    safe: 'bg-gradient-to-r from-success to-accent-primary',
    medium: 'bg-gradient-to-r from-accent-primary to-warning',
    low: 'bg-gradient-to-r from-warning to-error',
  };

  const variants = {
    default: 'bg-accent-primary',
    gradient: 'bg-gradient-to-r from-accent-primary to-accent-secondary',
    success: 'bg-success',
    error: 'bg-error',
  };

  return (
    <div className={cn('w-full', className)}>
      <div
        className={cn('bg-bg-tertiary w-full overflow-hidden rounded-full', sizes[size])}
        role="progressbar"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={max}
      >
        <div
          className={cn(
            'h-full rounded-full transition-all duration-500 ease-out',
            timerGradient ? timerGradients[timerGradient] : variants[variant],
            animated && 'animate-pulse'
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showLabel && (
        <div className="text-text-secondary mt-1.5 flex justify-between text-xs">
          <span>{value}</span>
          <span>{max}</span>
        </div>
      )}
    </div>
  );
}
