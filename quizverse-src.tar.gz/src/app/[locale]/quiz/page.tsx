import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ExploreEditorialPage } from '@/components/home/explore-editorial-page';
import { getExplorePayload } from '@/lib/data/public';
import { getDictionary, hasLocale } from '@/lib/i18n/dictionaries';
import { buildMetadata } from '@/lib/seo/metadata';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  if (!hasLocale(locale)) {
    return {};
  }

  return buildMetadata({
    title:
      locale === 'es'
        ? 'Explora todos los quizzes — trivia, personalidad y fandom'
        : 'Explore all quizzes — trivia, personality and fandom',
    description:
      locale === 'es'
        ? 'Explora el catálogo completo de QuizVerse por tema, mood y ritmo. Trivia, tests de personalidad y retos de fandom gratis.'
        : 'Browse the full QuizVerse catalog by topic, mood and pace. Free trivia rounds, personality tests and fandom challenges.',
    path: `/${locale}/quiz`,
    alternatePath: `/${locale === 'es' ? 'en' : 'es'}/quiz`,
    locale,
  });
}

export default async function LocalizedQuizExplorerPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!hasLocale(locale)) notFound();

  const dictionary = await getDictionary(locale);
  const payload = await getExplorePayload(locale);

  return (
    <ExploreEditorialPage
      locale={locale}
      quizzes={payload.quizzes}
      categories={payload.categories}
      copy={{
        title: dictionary.explore.title,
        subtitle: dictionary.explore.subtitle,
        searchPlaceholder: dictionary.explore.searchPlaceholder,
        emptyTitle: dictionary.explore.emptyTitle,
        emptyBody: dictionary.explore.emptyBody,
        allCategories: dictionary.explore.allCategories,
        eyebrow: locale === 'es' ? 'Explorar' : 'Explore',
        visibleNow: locale === 'es' ? 'Visibles ahora' : 'Visible now',
        playsInView: locale === 'es' ? 'Partidas en vista' : 'Plays in view',
        publishedNow: locale === 'es' ? 'Publicados ahora' : 'Published now',
        searchLabel: locale === 'es' ? 'Buscar' : 'Search',
        categoryLanes: locale === 'es' ? 'Carriles de categoría' : 'Category lanes',
        leadPick: locale === 'es' ? 'Selección principal' : 'Lead pick',
        moreWaysIn: locale === 'es' ? 'Más caminos de entrada' : 'More ways in',
        quizzesAfterFilters: locale === 'es' ? 'quizzes tras filtros' : 'quizzes after filters',
      }}
    />
  );
}
