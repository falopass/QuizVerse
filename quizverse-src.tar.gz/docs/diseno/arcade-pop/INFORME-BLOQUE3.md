# Bloque 3 — auditoría arcade pop

## Resultado y evidencia

| Punto | Cambio | Evidencia |
| --- | --- | --- |
| 1. Navegación de categorías | `personality` y `trivia` consultan `quiz_type`; los chips de categorías salen solo de categorías con quizzes publicados. Destinos directos sin juegos muestran el estado 404. | En servidor local conectado al catálogo: EN/ES `personality` 139 tarjetas, `trivia` 120, `culture` 237 y `lifestyle` 22. El filtro muestra solo Cultura y Estilo de vida. `/en/category/music` no muestra tarjetas y recibe el mensaje de no encontrado. `tests/category-paging.test.ts` conserva la paginación más allá de 500. |
| 2. Portadas | `QuizCoverArt` ya usa el título real completo; se redujo el tamaño de `.arcade-card-art .arcade-cover-title` para que los títulos largos no se recorten como rótulos genéricos. No hay fallback `FAN TEST`/`YOUR ROLE` en ese componente. | Revisión del componente y CSS; las 237 tarjetas de Cultura se entregan en la respuesta local. El render visual de la grilla no pudo medirse en Chromium desde este entorno. |
| 3. Idioma del detalle | Mapa bidireccional de 183 pares de slugs procedente del seed normalizado, comprobación de que el par está publicado y fallback a la home del idioma elegido. También se corrigió el alternativo SEO y se fuerza la OG propia del quiz. | `/api/quiz/locale?slug=en-the-white-lotus-fan-trivia-challenge&from=en&to=es` devuelve `/es/quiz/es-trivia-fan-de-the-white-lotus`; el caso Re:ZERO funciona al revés; slug desconocido devuelve `/es`. Test de ambos sentidos y fallback. |
| 4. Invitado | Si el retorno de login apunta a Crear, «Continuar como invitado» lleva a la home del idioma elegido. | Revisión del `href` en `LoginPageView`; Crear sigue protegido para publicar. |
| 5. Español | `html lang` se obtiene de la ruta en SSR y se actualiza al navegar; login tiene metadata ES; 404, copy del hero y nombres de categorías tienen traducción. Los chips vacíos se ocultan. | GET local `/es` entrega `<html lang="es">`; `/es/login` entrega `Iniciar sesión | QuizVerse`. |
| 6. Cookies | Botones de 44 px o más, banner en el flujo del documento en móvil y color de texto atenuado aclarado. El idioma se deriva de la ruta actual, también tras navegación cliente. | Revisión de CSS y `CookieConsentBanner`; sin medición de contraste ni captura de viewport en Chromium. |
| 7. Navegación táctil | Menú con botón y panel para Explore/Personalidad/Trivia bajo 1024 px; logo, enlaces de header y footer y selector de idioma con mínimo de 44 px. | Revisión de DOM/CSS. |
| 8. h1 a 320 px | Tamaño fluido y `overflow-wrap: anywhere` en el título de categoría. | Revisión de CSS; sin medición de desborde en navegador. |
| 9. Scripts Vercel | Retirados `Analytics` y `SpeedInsights` del layout. | El layout ya no emite esos componentes. |
| 10. OG | OG raíz/localizada oscuras con lima y Archivo Black; la OG del quiz incluye el título y SVG de la portada. 1200×630. | GET local de `/opengraph-image` y de la OG de White Lotus: ambos `200 image/png`; se inspeccionaron las imágenes renderizadas. Fuente Archivo Black de [Google Fonts](https://github.com/google/fonts/tree/main/ofl/archivoblack), con licencia OFL incluida. |
| 11. Pie | Tagline nuevo EN/ES acorde a Arcade pop. | `dictionaries.ts`, ambas entradas `footer.tagline`. |
| 12. Rutas técnicas | `/sitemap.xml` reescribe a `/api/sitemap`; `/callback` y `/ronda-diseno` quedan fuera del prefijo de idioma. | GET local `/sitemap.xml`: `200 application/xml`; `/callback`: 307 del flujo de auth, sin redirección a `/en/callback`. |
| 13. Quiz inexistente | Estado visible «no encontrado» bilingüe con enlaces al catálogo y la home. | `/en/quiz/no-existe-esta-ruta` muestra el texto del 404, pero la respuesta HTTP sigue siendo **200** por streaming. Se gana una salida clara para personas; se pierde el estado 404 correcto para bots. No se fijó `dynamicParams=false` porque el catálogo admite nuevos quizzes publicados. |
| 14. Resultado | Se quitó la ceja redundante «RESULT» y «Play another» tiene borde y tratamiento de acción secundaria. | Revisión de `result-screen.tsx` y `.arcade-result-secondary`. |
| 15. Partida a 320 px | Barra de poderes en una sola línea con scroll interno, menos padding y márgenes en cabecera/pregunta. Aviso de cookies en flujo móvil. | Revisión de CSS; sin medición de coordenadas de la primera opción en Chromium. |

## Verificaciones

- `npm run typecheck`: OK.
- `npm run lint`: 0 errores, 26 advertencias existentes fuera del cambio (scripts, analytics y sitemap).
- `npm test -- --run`: 7 archivos, 69 tests aprobados.
- `npm run build`: OK, 135 páginas generadas.
- Smoke HTTP local: conteos EN/ES 139/120/237/22 para tipo/categoría; XML, callback, API de idioma y OG comprobados.

## Fuera de alcance y límites

- El invitado navega a la home; crear/publicar sin cuenta requeriría un flujo de borrador anónimo y cambios de autorización en servidor.
- Solo hay mapa para los 183 pares presentes en el seed normalizado. Un quiz sin par conocido o sin contraparte publicada vuelve a la home del idioma elegido.
- No se pudo automatizar un viewport de Chromium en este entorno: el navegador disponible no entregó captura. Quedan pendientes la medición visual de 320×568 y 390×844, el contraste calculado y la revisión táctil real tras el despliegue.
- El 200 del quiz inexistente requiere modificar la frontera de streaming para convertirse en HTTP 404; aquí se eligió la página útil para navegación.
